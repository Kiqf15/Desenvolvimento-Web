var express = require('express')

var http = require("http");

var app = express();

app.use(express.static("./public"));
var servidor = http.createServer(app)

servidor.listen(3000)

console.log("servidor rodando. . . ")