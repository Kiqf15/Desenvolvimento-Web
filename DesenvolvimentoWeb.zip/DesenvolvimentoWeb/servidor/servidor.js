var express = require("express")
var http = require("http")
var bodyParser = require("body-parser")


var app = express()
app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json())

app.use(express.static("./public"))

app.set("view engine", "ejs")

app.get("/cadastra", function(req,resp){
    resp.render("cadastra")
})

app.get(["/","/login"], function(req, resp){
    resp.render("index")
})

app.get('/cadastro', function(req, resp){
    resp.write("Cadastrado com sucesso")
    resp.end()
})

app.post("/", function(req,resp){
    let login = req.body.login
    let senha = req.body.senha

    if(login === "kaique" && senha === "kiq"){
        var mensagem = "Sucesso"
        resp.render("resposta", {login, senha, mensagem})
    }
    else{
        var mensagem = "Falha"
        resp.render("resposta", {login, senha, mensagem})
    }
})

var servidor = http.createServer(app)
servidor.listen(80)
console.log("Servidor rodando")