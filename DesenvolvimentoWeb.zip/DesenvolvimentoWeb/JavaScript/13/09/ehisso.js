let nome = prompt("Digite seu nome:")
let idade = prompt("Digite sua idade:")
let ano_novo = prompt("Digite o ano atual:")

let nascimento = ano_atual - idade;

document.getElementById("nome").innerHTML = "O seu nome é" + nome;
document.getElementById("nascimento").innerText = "Você nasceu no ano de " + nascimento;

<input type = "Nome:" ></input>


