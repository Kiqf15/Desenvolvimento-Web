const mongoose = require('mongoose')
mongoose.connect("mongodb://localhost:27017/loja")
const PostSchema = new mongoose.Schema({
  ID: {
    type: String,
  },
  nome: {
    type: String,
  },
  marca: {
    type: String,
  },
  quantidade: {
    type: String,
  },
})

module.exports = mongoose.model('Post', PostSchema)
