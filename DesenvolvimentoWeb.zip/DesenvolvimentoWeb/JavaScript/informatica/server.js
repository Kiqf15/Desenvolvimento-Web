let http = require("http");
let express = require("express");
var mongoose = require("mongoose");
const { isValidObjectId } = require("mongoose");
const { render } = require("ejs");
mongoose.connect("mongodb://localhost/paginaprincipal");
var app = express();

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static("./public"));

app.set("view engine", "ejs");
app.set("views", "./views");

let postSchema = new mongoose.Schema({
  ID: String,
  nome: String,
  marca: String,
  quantidade: String,
});
let postModel = mongoose.model("usuario", postSchema);

app.get("/", function(req, res){
    res.render("principal");
    res.end()
  });

app.get("/cadastrar", function(res,resp){
    resp.render("cadastrar")
})

app.post("/cadastrar", function(res,resp){
    var IDP = res.body.IDPc
    var IN = res.body.NPc
    var IM = res.body.MPc
    var IQ = res.body.QPc

    var novo = new postModel({
        ID: IDP,
        nome: IN,
        marca: IM,
        quantidade: IQ,
    })
    novo.save();
    console.log(IDP,IN,IM,IQ)
    resp.write("<h1>Produto cadastrado com sucesso</h1><a href='/'>Página Principal</a>")
    resp.end()
})

app.get("/buscar", function(res,resp){
    resp.render("buscar")
})

app.post("/buscar", function(res,resp){
    var IN = res.body.NPc
    
    postModel.find({nome: IN}, function(erro,listanome){
      if (listanome.length <= 0){
        resp.write("<head><meta charset='UTF-8'></head><h1>Produto não encontrado</h1><br><a href='/'>Home</a>")
        resp.end()
      }
      resp.render("tabela", {listanome})
    })
})

app.get("/atualizar", function(res,resp){
    resp.render("atualizar")
})

app.post("/atualizar", function(res,resp){
    var IDP = res.body.IDPc
    var IN = res.body.NPc
    var IM = res.body.MPc
    var IQ = res.body.QPc

    postModel.updateOne({ID:IDP},{nome:IN, marca:IM, quantidade:IQ},
      function(erro,obj){
        if (obj.modifiedCount === 0){
          resp.write("<h1>ID não encontrado!! </h1><a href='/'>Página Principal</a>")
          resp.end()
        }
        else{
          resp.write("<h1>Produto Atualizado </h1><a href='/'>Página Principal</a>")
          resp.end()
        }
    })
    

})

app.get("/deletar", function(res,resp){
    resp.render("deletar")
})

app.post("/deletar", function(res,resp){
    var IDP = res.body.IDPc

    postModel.deleteOne({ID:IDP},function(error,obj){
      if (obj.deletedCount === 0){
        resp.write("<h1> ID não encontrado!!</h1><a href='/'>Página Principal</a>")
        resp.end()
      }
      else{
        resp.write("<h1>Produto Deletado!!</h1><a href='/'>Página Principal</a>")
        resp.end()
      }
    })
  
})



app.listen(3333, () => console.log("Server is running in :3333 !!"));