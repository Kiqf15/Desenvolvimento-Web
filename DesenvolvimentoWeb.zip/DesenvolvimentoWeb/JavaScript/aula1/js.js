/* for(let i = 1; i <= 100; i++){
    n = i % 2
    if (n == 0){
        console.log('Impar');
    }
    else{
        break
    }
} */

/* var y = 0
for(let x = 1; x <= 500; x ++){
    if (x % 5 === 0){
        console.log(x)
    }    
    else{
        continue
    }
} */

