window.onload = function() {

    var canvas = document.getElementById("myCanvas");
    var ctx = canvas.getContext("2d");
    var x_mouse = 0
    var y_mouse = 0


    addEventListener("mousemove", function(evento) {
        rect = canvas.getBoundingClientRect();
        x_mouse = evento.clientX - rect.left
        y_mouse = evento.clientY - rect.top
    })

    let quadrado = {
        x: 0,
        y: 0,
        largura: 30,
        altura: 30,
        cor: "red"
    }


    function mouse() {
        ctx.clearRect(0,0, canvas.width, canvas.height)

        ctx.fillStyle = quadrado.cor
        if (x_mouse < 15){
            x_mouse = 15
        }
        else if (x_mouse > 285){
            x_mouse = 285
        }
        if (y_mouse < 15){
            y_mouse = 15
        }
        else if (y_mouse > 285){
            y_mouse = 285
        }
        ctx.fillRect(x_mouse - 15, y_mouse - 15, quadrado.largura, quadrado.altura);

        requestAnimationFrame(mouse)
    }

    mouse();

}