window.onload = function() {

var canvas = document.getElementById("myCanvas");
var ctx = canvas.getContext("2d");

function desenharRetangulos(){
    ctx.fillStyle = "blue"
    ctx.fillRect(0, 0, 60, 60)

    ctx.fillStyle = "red"
    ctx.fillRect(240, 0, 60, 60)
    
    ctx.fillStyle = "cyan"
    ctx.fillRect(270, 135, 30, 30)

    ctx.fillStyle = "cyan"
    ctx.fillRect(0, 120, 30, 60)

    ctx.fillStyle = "red"
    ctx.fillRect(105, 150, 45,45)

    ctx.fillStyle = "yellow"
    ctx.fillRect(0, 240, 60, 60)

    ctx.fillStyle = "black"
    ctx.fillRect(240, 240, 60, 60)

    ctx.fillStyle = "white"
    ctx.fillRect(30, 240, 30, 30)

    ctx.fillStyle = "white"
    ctx.fillRect(240, 240, 30, 30)
}

function desenharLinhas(){
    ctx.beginPath()
    ctx.strokeStyle = "blue"
    ctx.moveTo(0,0)
    ctx.lineTo(150, 150)
    ctx.stroke()

    ctx.beginPath()
    ctx.moveTo(300,0)
    ctx.strokeStyle = "red"
    ctx.lineTo(150, 150)
    ctx.stroke()

    ctx.beginPath()
    ctx.strokeStyle = "green"
    ctx.moveTo(0,150)
    ctx.lineTo(300, 150)
    ctx.stroke()

    ctx.beginPath()
    ctx.strokeStyle = "green"
    ctx.moveTo(150,150)
    ctx.lineTo(150, 270)
    ctx.stroke()
}

function desenharArcos() {
    ctx.fillStyle = "cyan"
    ctx.beginPath()
    ctx.strokeStyle = "blue"
    ctx.arc(150, 120, 15, 0, 2*Math.PI)
    ctx.stroke()
    ctx.fill()

    ctx.fillStyle = "yellow"
    ctx.beginPath()
    ctx.strokeStyle = "green"
    ctx.arc(75, 225, 15, 0, 2*Math.PI)
    ctx.stroke()
    ctx.fill()

    ctx.fillStyle = "yellow"
    ctx.beginPath()
    ctx.strokeStyle = "green"
    ctx.arc(225, 225, 15, 0, 2*Math.PI)
    ctx.stroke()
    ctx.fill()

    ctx.fillStyle = "cyan"
    ctx.beginPath()
    ctx.strokeStyle = "green"
    ctx.arc(150, 300, 40, 0, 2*Math.PI)
    ctx.stroke()
    ctx.fill()
    
    ctx.beginPath()
    ctx.strokeStyle = "green"
    ctx.arc(150, 300, 60, 1.5*Math.PI, 2*Math.PI)
    ctx.stroke()

    ctx.beginPath()
    ctx.strokeStyle = "green"
    ctx.arc(150, 300, 80, 1*Math.PI, 1.5*Math.PI)
    ctx.stroke()
    
    ctx.beginPath()
    ctx.strokeStyle = "green"
    ctx.arc(150, 150, 60, 1.*Math.PI, 2*Math.PI)
    ctx.stroke()
    
    ctx.beginPath()
    ctx.strokeStyle = "green"
    ctx.arc(150, 150, 80, 1*Math.PI, 1.25*Math.PI)
    ctx.stroke()
    
    ctx.beginPath()
    ctx.strokeStyle = "green"
    ctx.arc(150, 150, 80, 1.75*Math.PI, 2*Math.PI)
    ctx.stroke()

}

function escrever(){
    ctx.font = "22px Arial"
    ctx.fillStyle = "black"
    ctx.fillText("Canvas", 110, 60)

}

desenharRetangulos()
desenharLinhas()
desenharArcos()
escrever()
}