// bango = número
var bango= Math.floor(Math.random() * 100);
// suisoku = palpite
var suisoku = document.querySelector('.suisoku');
// kekka = resultado
var kekka = document.querySelector('.kekka');
// HikuiTakai = BaixoAlto
var HikuiTakai = document.querySelector('.HikuiTakai');
// unso = envio
var unso = document.querySelector('.unso');
// sutoreji = armazém
var sutoreji = document.querySelector('.sutoreji');
// sukoa = contagem
var sukoa = 0;
// sakido = reinício
var sakido;
sutoreji.focus();

// função para conferir o palpite
// chekku = conferir
function chekku() {
    // receber do usuário (yuza = usuário)
    var yuza = Number(sutoreji.value);
    if (sukoa === 0) {
      suisoku.textContent = 'Palpites anteriores: ';
    }
    suisoku.textContent += yuza + ' ';
  
    if (yuza === bango) {
      kekka.textContent = 'Parabéns! Você acertou!';
      kekka.style.backgroundColor = 'green';
      HikuiTakai
    .textContent = '';
      GemuShuryo();
    } else if (sukoa === 10) {
      kekka.textContent = '!!!FIM DE JOGO!!!';
      kekka.style.fontSize = '40pt';
      window.confirm("!!!Fim de Jogo!!!")
      HikuiTakai
    .textContent = '';
      GemuShuryo();
    } else {
      kekka.textContent = 'Errado!';
      kekka.style.backgroundColor = 'red';
      if(yuza < bango) {
        HikuiTakai
    .textContent = 'Seu palpite está baixo!';
      } else if(yuza > bango) {
        HikuiTakai
    .textContent = 'Seu palpite está alto!';
      }
    }
    
    document.getElementById("audio").play()
    sukoa++;
    sutoreji.value = '';
    sutoreji.focus();
}

chekku()


// função para encerrar o game
// Fim de jogo = Gemu Shuryo
function GemuShuryo() {
    sutoreji.disabled = true;
    unso.disabled = true;
    document.getElementById("GemuShuryo").style.display = "block"
}

// Função para reiniciar o game
// reiniciar = sakido
function sakido() {
    sukoa = 1;
//   condição para reiniciar o jogo
    var saikido = document.querySelectorAll('.resultadoParas p');
    for (var i = 0 ; i < saikido.length ; i++) {
      saikido[i].textContent = '';
    }
  
    sakido.parentNode.removeChild(sakido);
  
    sutoreji.disabled = false;
    unso.disabled = false;
    sutoreji.value = '';
    sutoreji.focus();
  
    kekka.style.backgroundColor = 'white';
  
    bango = Math.floor(Math.random() * 100);
}

function reload(){
    setTimeout(() => {
        window.location.reload()
    }, 1000);
}